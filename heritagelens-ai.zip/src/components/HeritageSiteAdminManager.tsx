import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Save, 
  RotateCcw, 
  Download, 
  Upload, 
  Check, 
  AlertCircle, 
  Search, 
  ExternalLink, 
  Sparkles, 
  Eye, 
  Code, 
  CheckCircle2, 
  Copy, 
  RefreshCw,
  MapPin,
  Clock,
  Ticket,
  Train,
  FileText,
  HelpCircle,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { HeritageSite } from '../types';
import { HeritageDataStore } from '../services/heritageDataStore';
import { handleMonumentImageError } from '../utils/imageFallback';

interface HeritageSiteAdminManagerProps {
  currentLang: 'en' | 'hi';
  onSiteSelectForDemo?: (siteId: string) => void;
}

export const HeritageSiteAdminManager: React.FC<HeritageSiteAdminManagerProps> = ({
  currentLang,
  onSiteSelectForDemo
}) => {
  const [sites, setSites] = useState<HeritageSite[]>([]);
  const [selectedSiteId, setSelectedSiteId] = useState<string>('');
  const [editingSite, setEditingSite] = useState<HeritageSite | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  // UI state
  const [activeTab, setActiveTab] = useState<'basic' | 'history' | 'facts' | 'travel' | 'nearby' | 'json'>('basic');
  const [imageTestStatus, setImageTestStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [imageErrorMessage, setImageErrorMessage] = useState('');
  const [feedbackToast, setFeedbackToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [isNewSiteModalOpen, setIsNewSiteModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [rawJsonEditText, setRawJsonEditText] = useState('');
  const [rawJsonError, setRawJsonError] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(false);

  // Load sites from data store
  const refreshSites = () => {
    const loaded = HeritageDataStore.getAllSites();
    setSites(loaded);
    if (loaded.length > 0) {
      // Keep selected or pick first
      const currentExists = loaded.find(s => s.id === selectedSiteId);
      const targetSite = currentExists || loaded[0];
      setSelectedSiteId(targetSite.id);
      setEditingSite(JSON.parse(JSON.stringify(targetSite)));
      setRawJsonEditText(JSON.stringify(targetSite, null, 2));
      setIsDirty(false);
    }
  };

  useEffect(() => {
    refreshSites();
    const unsubscribe = HeritageDataStore.subscribe(() => {
      const all = HeritageDataStore.getAllSites();
      setSites(all);
    });
    return unsubscribe;
  }, []);

  // When selected site changes
  const handleSelectSite = (siteId: string) => {
    if (isDirty) {
      if (!window.confirm(currentLang === 'en' 
        ? 'You have unsaved edits on the current monument. Switch anyway?' 
        : 'वर्तमान स्मारक में बिना सहेजे गए बदलाव हैं। क्या आप फिर भी बदलना चाहते हैं?')) {
        return;
      }
    }
    const target = sites.find((s) => s.id === siteId);
    if (target) {
      setSelectedSiteId(siteId);
      setEditingSite(JSON.parse(JSON.stringify(target)));
      setRawJsonEditText(JSON.stringify(target, null, 2));
      setImageTestStatus('idle');
      setImageErrorMessage('');
      setIsDirty(false);
    }
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setFeedbackToast({ message, type });
    setTimeout(() => setFeedbackToast(null), 3500);
  };

  // Test Image URL helper
  const handleTestImageUrl = (url: string) => {
    if (!url || !url.trim()) {
      setImageTestStatus('error');
      setImageErrorMessage(currentLang === 'en' ? 'Image link is empty' : 'चित्र लिंक खाली है');
      return;
    }

    setImageTestStatus('loading');
    setImageErrorMessage('');

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.referrerPolicy = 'no-referrer';
    
    img.onload = () => {
      setImageTestStatus('success');
      showToast(currentLang === 'en' ? 'Image link verified successfully! 📸' : 'चित्र लिंक सफलतापूर्वक सत्यापित हुआ!', 'success');
    };

    img.onerror = () => {
      setImageTestStatus('error');
      setImageErrorMessage(currentLang === 'en' 
        ? 'Unable to load image. The link might be blocked by CORS or broken. Try using Unsplash or direct image CDN URLs.' 
        : 'चित्र लोड नहीं हो सका। कृपया दूसरा सीधा CDN या Unsplash लिंक आज़माएं।');
    };

    img.src = url.trim();
  };

  // Update specific field in editingSite
  const handleFieldChange = (path: string, value: any) => {
    if (!editingSite) return;
    const updated = { ...editingSite };
    
    if (path.includes('.')) {
      const [parent, child] = path.split('.');
      (updated as any)[parent] = {
        ...(updated as any)[parent],
        [child]: value
      };
    } else {
      (updated as any)[path] = value;
    }

    setEditingSite(updated);
    setRawJsonEditText(JSON.stringify(updated, null, 2));
    setIsDirty(true);

    if (path === 'imageUrl') {
      setImageTestStatus('idle');
    }
  };

  // Save current site
  const handleSaveCurrentSite = () => {
    if (!editingSite) return;

    if (!editingSite.name?.trim()) {
      showToast(currentLang === 'en' ? 'Monument name cannot be empty!' : 'स्मारक का नाम खाली नहीं हो सकता!', 'error');
      return;
    }

    try {
      HeritageDataStore.saveSite(editingSite);
      setIsDirty(false);
      refreshSites();
      showToast(
        currentLang === 'en' 
          ? `Saved changes for "${editingSite.name}"! Available across all views.` 
          : `"${editingSite.hindiName || editingSite.name}" के बदलाव सहेजे गए!`,
        'success'
      );
    } catch (err: any) {
      showToast(err?.message || 'Failed to save site', 'error');
    }
  };

  // Reset to defaults
  const handleResetToDefaults = () => {
    const confirm = window.confirm(
      currentLang === 'en'
        ? 'Reset all 10 heritage sites to the factory default records? All custom additions and image URLs will be restored.'
        : 'क्या आप सभी 10 धरोहर स्थलों को मूल फ़ैक्टरी डेटा पर रीसेट करना चाहते हैं?'
    );
    if (confirm) {
      const defaults = HeritageDataStore.resetToDefaults();
      setSites(defaults);
      if (defaults.length > 0) {
        setSelectedSiteId(defaults[0].id);
        setEditingSite(JSON.parse(JSON.stringify(defaults[0])));
        setRawJsonEditText(JSON.stringify(defaults[0], null, 2));
      }
      setIsDirty(false);
      showToast(currentLang === 'en' ? 'Reset to default verified sites complete.' : 'मूल डेटा रीसेट पूरा हुआ।', 'info');
    }
  };

  // Create new blank or templated site
  const handleCreateNewSite = (templateId?: string) => {
    let base: Partial<HeritageSite> = {
      id: `custom-monument-${Date.now().toString().slice(-4)}`,
      name: 'New Heritage Monument',
      hindiName: 'नया धरोहर स्थल',
      shortDescription: 'Add a concise summary of the architectural and historical significance here.',
      hindiShortDescription: 'यहाँ इस ऐतिहासिक स्मारक का संक्षिप्त विवरण दर्ज करें।',
      fullHistory: 'Detailed chronological history and builder details.',
      hindiFullHistory: 'विस्तृत ऐतिहासिक विवरण।',
      builtYear: '16th Century CE',
      builtBy: 'Historic Dynasty / Builder',
      architecturalStyle: 'Indo-Islamic / Rajput / Ancient',
      culturalSignificance: 'Cultural importance and heritage recognition.',
      hindiCulturalSignificance: 'सांस्कृतिक महत्व और धरोहर मान्यता।',
      interestingFacts: ['Interesting fact #1', 'Interesting fact #2'],
      hindiInterestingFacts: ['रोचक तथ्य #1', 'रोचक तथ्य #2'],
      folkloreOrLegends: ['Folklore or local legend associated with the site.'],
      hindiFolkloreOrLegends: ['स्मारक से जुड़ी स्थानीय लोककथा।'],
      travelTips: {
        timings: '9:00 AM – 5:30 PM (All days)',
        entryFee: '₹25 for Indians, ₹300 for Foreigners',
        nearestMetro: 'Central Secretariat or nearest station',
        bestTimeToVisit: 'October to March (Morning / Evening)',
        rules: ['Photography permitted', 'Footwear rules apply']
      },
      nearbyAttractions: [
        { name: 'Nearby Garden / Market', distance: '500 m', description: 'Popular attraction nearby' }
      ],
      imageUrl: 'https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?auto=format&fit=crop&w=1200&q=80',
      imageAlt: 'Monument facade and heritage architectural structure',
      sourceNote: 'Archaeological Survey of India (ASI) / Historical Gazetteers',
      tags: ['Heritage', 'Historic Site', 'Monument']
    };

    if (templateId) {
      const template = sites.find(s => s.id === templateId);
      if (template) {
        base = {
          ...JSON.parse(JSON.stringify(template)),
          id: `${template.id}-copy-${Date.now().toString().slice(-4)}`,
          name: `${template.name} (Copy)`,
          hindiName: `${template.hindiName} (प्रतिलिपि)`
        };
      }
    }

    const { site } = HeritageDataStore.addNewSite(base as HeritageSite);
    refreshSites();
    setSelectedSiteId(site.id);
    setEditingSite(site);
    setRawJsonEditText(JSON.stringify(site, null, 2));
    setIsNewSiteModalOpen(false);
    showToast(currentLang === 'en' ? `Created new site "${site.name}"!` : `नया स्थल "${site.hindiName}" बनाया गया!`, 'success');
  };

  // Delete site
  const handleDeleteSite = (id: string) => {
    const site = sites.find(s => s.id === id);
    if (!site) return;

    if (sites.length <= 1) {
      showToast(currentLang === 'en' ? 'Cannot delete the last remaining monument.' : 'अंतिम शेष स्मारक को हटाया नहीं जा सकता।', 'error');
      return;
    }

    const confirm = window.confirm(
      currentLang === 'en'
        ? `Are you sure you want to delete "${site.name}" (${site.id}) from the catalog?`
        : `क्या आप वास्तव में "${site.hindiName || site.name}" को हटाना चाहते हैं?`
    );

    if (confirm) {
      HeritageDataStore.deleteSite(id);
      refreshSites();
      showToast(currentLang === 'en' ? `Deleted "${site.name}".` : `"${site.name}" हटा दिया गया।`, 'info');
    }
  };

  // Export JSON
  const handleExportJson = () => {
    const jsonStr = HeritageDataStore.exportAsJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `heritagelens-delhi-sites-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(currentLang === 'en' ? 'Exported heritage sites JSON.' : 'हेरिटेज साइट्स JSON एक्सपोर्ट किया गया।', 'success');
  };

  // Import JSON
  const handleImportJson = () => {
    if (!importJsonText.trim()) return;
    const res = HeritageDataStore.importFromJson(importJsonText);
    if (res.success) {
      refreshSites();
      setIsImportModalOpen(false);
      setImportJsonText('');
      showToast(currentLang === 'en' ? `Successfully imported ${res.count} sites!` : `${res.count} स्थल सफलतापूर्वक आयात किए गए!`, 'success');
    } else {
      showToast(res.error || 'Import failed', 'error');
    }
  };

  // Apply Raw JSON editor changes
  const handleApplyRawJson = () => {
    try {
      setRawJsonError(null);
      const parsed = JSON.parse(rawJsonEditText);
      if (!parsed.id || !parsed.name) {
        throw new Error("JSON must include 'id' and 'name' properties.");
      }
      setEditingSite(parsed);
      HeritageDataStore.saveSite(parsed);
      setIsDirty(false);
      refreshSites();
      showToast(currentLang === 'en' ? 'Applied raw JSON changes!' : 'रॉ JSON बदलाव लागू किए गए!', 'success');
    } catch (err: any) {
      setRawJsonError(err.message || 'Invalid JSON');
      showToast(err.message || 'Invalid JSON syntax', 'error');
    }
  };

  // Filter sites for sidebar/selector
  const filteredSites = sites.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.hindiName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="heritage-admin-setting-container" className="w-full flex flex-col gap-6">
      {/* Toast Notification */}
      <AnimatePresence>
        {feedbackToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-sm font-bold ${
              feedbackToast.type === 'success'
                ? 'bg-[#2C4A3E] text-white border-[#3F6A59]'
                : feedbackToast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-700'
                : 'bg-[#1E293B] text-white border-slate-700'
            }`}
          >
            {feedbackToast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#D4AF37]" />}
            {feedbackToast.type === 'error' && <AlertCircle className="w-5 h-5 text-rose-300" />}
            {feedbackToast.type === 'info' && <Info className="w-5 h-5 text-sky-300" />}
            <span>{feedbackToast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner & Global Actions */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-[#2D2926] via-[#3D3530] to-[#1F1C1A] text-white border border-[#4A423C] shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-full bg-radial from-[#D4AF37]/15 to-transparent pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-bold tracking-wider mb-2 uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{currentLang === 'en' ? 'Admin Data & Image Link Manager' : 'व्यवस्थापक डेटा एवं चित्र प्रबंधक'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif-heritage text-white flex items-center gap-3">
              <Building2 className="w-7 h-7 text-[#D4AF37]" />
              <span>{currentLang === 'en' ? 'Heritage Monuments Catalog' : 'धरोहर स्मारक सूची एवं विवरण'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-2xl leading-relaxed">
              {currentLang === 'en'
                ? 'Directly inspect and customize the stored information, history, facts, travel tips, and image links for all 10 verified monuments or add new ones.'
                : 'सभी 10 प्रमाणित स्मारकों के विवरण, इतिहास, रोचक तथ्य, यात्रा सुझाव और चित्र लिंक को मैन्युअल रूप से संपादित करें अथवा नए स्मारक जोड़ें।'}
            </p>
          </div>

          {/* Quick Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              id="admin-add-monument-btn"
              onClick={() => setIsNewSiteModalOpen(true)}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-[#C05E42] hover:bg-[#a84d34] text-white text-xs font-bold transition-all shadow-md flex items-center gap-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
            >
              <Plus className="w-4 h-4" />
              <span>{currentLang === 'en' ? '+ Add New Monument' : '+ नया स्मारक जोड़ें'}</span>
            </button>

            <button
              type="button"
              id="admin-export-json-btn"
              onClick={handleExportJson}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              title="Export as JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{currentLang === 'en' ? 'Export JSON' : 'निर्यात'}</span>
            </button>

            <button
              type="button"
              id="admin-import-json-btn"
              onClick={() => setIsImportModalOpen(true)}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              title="Import JSON"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{currentLang === 'en' ? 'Import JSON' : 'आयात'}</span>
            </button>

            <button
              type="button"
              id="admin-reset-defaults-btn"
              onClick={handleResetToDefaults}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-rose-300 hover:text-rose-200 border border-neutral-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              title="Reset all data to default verified records"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{currentLang === 'en' ? 'Reset Defaults' : 'रीसेट'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Layout: Monument Selector Sidebar + Detail Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Monument Selector List (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          <div className="p-4 rounded-2xl bg-white border border-[#E8E2D9] shadow-xs flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#C05E42]" />
                <h3 className="text-xs font-bold tracking-wider uppercase text-[#1A1A1A]">
                  {currentLang === 'en' ? `Monuments (${sites.length})` : `स्मारक सूची (${sites.length})`}
                </h3>
              </div>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#F3EEE7] text-[#5C544E] font-medium">
                {currentLang === 'en' ? 'Click to edit' : 'संपादन हेतु चुनें'}
              </span>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#8C827A] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={currentLang === 'en' ? 'Filter by name or slug...' : 'नाम या आईडी से खोजें...'}
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-[#FDFBF7] border border-[#E8E2D9] text-xs text-[#1A1A1A] placeholder-[#8C827A] focus:outline-none focus:border-[#C05E42]"
              />
            </div>
          </div>

          {/* List of Sites */}
          <div className="flex flex-col gap-2 max-h-[680px] overflow-y-auto pr-1">
            {filteredSites.map((site, index) => {
              const isSelected = site.id === selectedSiteId;
              return (
                <div
                  key={site.id}
                  onClick={() => handleSelectSite(site.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 group relative ${
                    isSelected
                      ? 'bg-[#FDFBF7] border-[#C05E42] shadow-sm ring-2 ring-[#C05E42]/20'
                      : 'bg-white border-[#E8E2D9] hover:border-[#D4AF37] hover:bg-[#FAF7F2]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Thumbnail */}
                    <div className="w-12 h-12 rounded-xl overflow-hidden bg-neutral-200 border border-[#E8E2D9] shrink-0 relative">
                      <img
                        src={site.imageUrl}
                        alt={site.name}
                        className="w-full h-full object-cover"
                        crossOrigin="anonymous"
                        referrerPolicy="no-referrer"
                        onError={(e) => handleMonumentImageError(e, site.id, site.name)}
                      />
                      <span className="absolute top-0.5 left-0.5 bg-black/70 text-white text-[9px] font-bold px-1 rounded">
                        #{index + 1}
                      </span>
                    </div>

                    {/* Titles */}
                    <div className="min-w-0 flex flex-col">
                      <h4 className="text-xs font-bold text-[#1A1A1A] truncate group-hover:text-[#C05E42] transition-colors">
                        {currentLang === 'hi' ? site.hindiName : site.name}
                      </h4>
                      <p className="text-[11px] text-[#8C827A] truncate font-mono">
                        {site.id}
                      </p>
                      <span className="text-[10px] text-[#5C544E] truncate">
                        {site.builtYear}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    {isSelected && (
                      <span className="w-2 h-2 rounded-full bg-[#C05E42] animate-pulse" />
                    )}
                    <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-[#C05E42]' : 'text-[#8C827A]'}`} />
                  </div>
                </div>
              );
            })}

            {filteredSites.length === 0 && (
              <div className="p-6 text-center text-xs text-[#8C827A] bg-white rounded-2xl border border-[#E8E2D9]">
                {currentLang === 'en' ? 'No monuments matched your query.' : 'कोई स्मारक नहीं मिला।'}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Active Site Detailed Editor (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {editingSite ? (
            <div className="p-6 rounded-3xl bg-white border border-[#E8E2D9] shadow-sm flex flex-col gap-6">
              
              {/* Site Top Bar with Status & Save Button */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8E2D9]">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-[#F3EEE7] text-[#5C544E] border border-[#E8E2D9]">
                      ID: {editingSite.id}
                    </span>
                    {isDirty && (
                      <span className="text-xs px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold border border-amber-300">
                        {currentLang === 'en' ? 'Unsaved changes' : 'अपरिवर्तित बदलाव'}
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-bold font-serif-heritage text-[#1A1A1A] mt-1">
                    {editingSite.name}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  {onSiteSelectForDemo && (
                    <button
                      type="button"
                      onClick={() => onSiteSelectForDemo(editingSite.id)}
                      className="px-3 py-2 rounded-xl bg-[#FDFBF7] hover:bg-[#F3EEE7] border border-[#E8E2D9] text-[#1A1A1A] text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                      title="Test recognition in camera demo"
                    >
                      <Eye className="w-3.5 h-3.5 text-[#C05E42]" />
                      <span>{currentLang === 'en' ? 'Test in Demo' : 'डेमो में देखें'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleCreateNewSite(editingSite.id)}
                    className="px-3 py-2 rounded-xl bg-[#FDFBF7] hover:bg-[#F3EEE7] border border-[#E8E2D9] text-[#1A1A1A] text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                    title="Clone as new monument template"
                  >
                    <Copy className="w-3.5 h-3.5 text-[#8C827A]" />
                    <span>{currentLang === 'en' ? 'Duplicate' : 'कॉपी बनाएं'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteSite(editingSite.id)}
                    className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                    title="Delete site from catalog"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{currentLang === 'en' ? 'Delete' : 'हटाएं'}</span>
                  </button>

                  <button
                    type="button"
                    id="admin-save-site-btn"
                    onClick={handleSaveCurrentSite}
                    className="px-4 py-2 rounded-xl bg-[#2C4A3E] hover:bg-[#223930] text-white text-xs font-bold transition-all shadow-md flex items-center gap-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
                  >
                    <Save className="w-4 h-4 text-[#D4AF37]" />
                    <span>{currentLang === 'en' ? 'Save Site Data' : 'डेटा सहेजें'}</span>
                  </button>
                </div>
              </div>

              {/* Sub Navigation Tabs */}
              <div className="flex flex-wrap items-center gap-1.5 bg-[#F8F5F0] p-1.5 rounded-2xl border border-[#E8E2D9]">
                {[
                  { id: 'basic', labelEn: 'Image & Identity', labelHi: 'चित्र एवं पहचान' },
                  { id: 'history', labelEn: 'Descriptions & History', labelHi: 'विवरण एवं इतिहास' },
                  { id: 'facts', labelEn: 'Facts & Folklore', labelHi: 'तथ्य एवं कथाएं' },
                  { id: 'travel', labelEn: 'Travel & Logistics', labelHi: 'यात्रा एवं नियम' },
                  { id: 'nearby', labelEn: 'Nearby Attractions', labelHi: 'निकटवर्ती आकर्षण' },
                  { id: 'json', labelEn: 'Raw JSON Editor', labelHi: 'रॉ JSON संपादक' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeTab === tab.id
                        ? 'bg-white text-[#1A1A1A] shadow-xs border border-[#E8E2D9]'
                        : 'text-[#5C544E] hover:text-[#1A1A1A] hover:bg-white/50'
                    }`}
                  >
                    {currentLang === 'hi' ? tab.labelHi : tab.labelEn}
                  </button>
                ))}
              </div>

              {/* TAB 1: IMAGE & BASIC IDENTITY */}
              {activeTab === 'basic' && (
                <div className="flex flex-col gap-6">
                  {/* Image Link Box with Live Preview */}
                  <div className="p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E2D9] flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ImageIcon className="w-4 h-4 text-[#C05E42]" />
                        <h4 className="text-xs font-bold tracking-wider uppercase text-[#1A1A1A]">
                          {currentLang === 'en' ? 'Monument Image Link (URL) & Live Preview' : 'स्मारक चित्र लिंक एवं लाइव प्रीव्यू'}
                        </h4>
                      </div>
                      <span className="text-[11px] text-[#5C544E]">
                        {currentLang === 'en' ? 'Direct CDN / HTTPS link required' : 'सीधा HTTPS लिंक आवश्यक'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
                      {/* Inputs */}
                      <div className="md:col-span-7 flex flex-col gap-3">
                        <div>
                          <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                            {currentLang === 'en' ? 'Primary Image URL:' : 'मुख्य चित्र URL:'}
                          </label>
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={editingSite.imageUrl}
                              onChange={(e) => handleFieldChange('imageUrl', e.target.value)}
                              placeholder="https://images.unsplash.com/photo-..."
                              className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs font-mono text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                            />
                            <button
                              type="button"
                              onClick={() => handleTestImageUrl(editingSite.imageUrl)}
                              className="px-3 py-2 rounded-xl bg-[#2D2926] hover:bg-[#403A36] text-white text-xs font-bold shrink-0 transition-colors cursor-pointer"
                              title="Test if image loads"
                            >
                              {currentLang === 'en' ? 'Test Link' : 'परीक्षण'}
                            </button>
                          </div>
                        </div>

                        {/* Status Message */}
                        {imageTestStatus === 'loading' && (
                          <p className="text-xs text-sky-700 flex items-center gap-1.5">
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>{currentLang === 'en' ? 'Checking image link...' : 'चित्र लिंक जांचा जा रहा है...'}</span>
                          </p>
                        )}
                        {imageTestStatus === 'success' && (
                          <p className="text-xs text-emerald-700 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{currentLang === 'en' ? 'Image link is valid and loaded successfully!' : 'चित्र लिंक वैध है और सफलतापूर्वक लोड हुआ!'}</span>
                          </p>
                        )}
                        {imageTestStatus === 'error' && (
                          <p className="text-xs text-rose-700 bg-rose-50 p-2.5 rounded-xl border border-rose-200">
                            {imageErrorMessage}
                          </p>
                        )}

                        <div>
                          <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                            {currentLang === 'en' ? 'Image Alt Text (Accessibility):' : 'चित्र विवरण (Alt Text):'}
                          </label>
                          <input
                            type="text"
                            value={editingSite.imageAlt}
                            onChange={(e) => handleFieldChange('imageAlt', e.target.value)}
                            placeholder="Architectural facade of monument..."
                            className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                          />
                        </div>

                        {/* Quick Presets / Tips */}
                        <div className="p-3 rounded-xl bg-white border border-[#E8E2D9] text-[11px] text-[#5C544E] flex flex-col gap-1">
                          <span className="font-bold text-[#1A1A1A]">
                            {currentLang === 'en' ? '💡 Tip for Image Links:' : '💡 चित्र लिंक के लिए सुझाव:'}
                          </span>
                          <span>
                            {currentLang === 'en'
                              ? 'You can paste high-resolution images from Unsplash, Imgur, direct cloud buckets, or reliable CDN links.'
                              : 'आप Unsplash, Imgur या सीधे CDN लिंक से उच्च-गुणवत्ता वाले चित्र URL पेस्ट कर सकते हैं।'}
                          </span>
                        </div>
                      </div>

                      {/* Live Image Preview Card */}
                      <div className="md:col-span-5 flex flex-col gap-2">
                        <span className="text-xs font-bold text-[#5C544E]">
                          {currentLang === 'en' ? 'Live Card Preview:' : 'लाइव कार्ड प्रीव्यू:'}
                        </span>
                        <div className="relative aspect-4/3 rounded-2xl overflow-hidden bg-neutral-900 border-2 border-[#D4AF37] shadow-md group">
                          <img
                            src={editingSite.imageUrl}
                            alt={editingSite.imageAlt || editingSite.name}
                            className="w-full h-full object-cover"
                            crossOrigin="anonymous"
                            referrerPolicy="no-referrer"
                            onError={(e) => handleMonumentImageError(e, editingSite.id, editingSite.name)}
                          />
                          <div className="absolute inset-0 bg-linear-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-3">
                            <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider">
                              {editingSite.architecturalStyle || 'Heritage Site'}
                            </span>
                            <h5 className="text-sm font-bold text-white font-serif-heritage leading-tight">
                              {currentLang === 'hi' ? editingSite.hindiName : editingSite.name}
                            </h5>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Core Identity Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Unique ID (Slug):' : 'विशिष्ट आईडी (Slug):'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.id}
                        disabled
                        className="w-full px-3 py-2 rounded-xl bg-neutral-100 border border-[#E8E2D9] text-xs font-mono text-neutral-600 cursor-not-allowed"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Built Year / Era:' : 'निर्माण वर्ष / काल:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.builtYear}
                        onChange={(e) => handleFieldChange('builtYear', e.target.value)}
                        placeholder="e.g. 1638–1648 CE"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'English Name:' : 'अंग्रेज़ी नाम:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.name}
                        onChange={(e) => handleFieldChange('name', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs font-bold text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Hindi Name (Devanagari):' : 'हिंदी नाम (देवनागरी):'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.hindiName}
                        onChange={(e) => handleFieldChange('hindiName', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs font-bold text-[#1A1A1A] font-devanagari focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Built By (Patron / Architect):' : 'निर्माता / वास्तुकार:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.builtBy}
                        onChange={(e) => handleFieldChange('builtBy', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Architectural Style:' : 'वास्तुशिल्प शैली:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.architecturalStyle}
                        onChange={(e) => handleFieldChange('architecturalStyle', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Tags (comma separated):' : 'टैग (कॉमा से अलग करें):'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.tags ? editingSite.tags.join(', ') : ''}
                        onChange={(e) => handleFieldChange('tags', e.target.value.split(',').map(t => t.trim()).filter(Boolean))}
                        placeholder="Mughal, UNESCO, Fortress"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Source Citation / Records:' : 'स्रोत / अभिलेख:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.sourceNote}
                        onChange={(e) => handleFieldChange('sourceNote', e.target.value)}
                        placeholder="Archaeological Survey of India (ASI)"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: DESCRIPTIONS & HISTORY */}
              {activeTab === 'history' && (
                <div className="flex flex-col gap-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Short Description (English):' : 'संक्षिप्त विवरण (अंग्रेज़ी):'}
                      </label>
                      <textarea
                        rows={3}
                        value={editingSite.shortDescription}
                        onChange={(e) => handleFieldChange('shortDescription', e.target.value)}
                        className="w-full p-3 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Short Description (Hindi):' : 'संक्षिप्त विवरण (हिंदी):'}
                      </label>
                      <textarea
                        rows={3}
                        value={editingSite.hindiShortDescription}
                        onChange={(e) => handleFieldChange('hindiShortDescription', e.target.value)}
                        className="w-full p-3 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] font-devanagari focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Full Historical Narrative (English):' : 'संपूर्ण ऐतिहासिक वृत्तांत (अंग्रेज़ी):'}
                      </label>
                      <textarea
                        rows={6}
                        value={editingSite.fullHistory}
                        onChange={(e) => handleFieldChange('fullHistory', e.target.value)}
                        className="w-full p-3 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] leading-relaxed focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Full Historical Narrative (Hindi):' : 'संपूर्ण ऐतिहासिक वृत्तांत (हिंदी):'}
                      </label>
                      <textarea
                        rows={6}
                        value={editingSite.hindiFullHistory}
                        onChange={(e) => handleFieldChange('hindiFullHistory', e.target.value)}
                        className="w-full p-3 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] font-devanagari leading-relaxed focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Cultural & Architectural Significance (English):' : 'सांस्कृतिक एवं वास्तुशिल्प महत्व (अंग्रेज़ी):'}
                      </label>
                      <textarea
                        rows={4}
                        value={editingSite.culturalSignificance}
                        onChange={(e) => handleFieldChange('culturalSignificance', e.target.value)}
                        className="w-full p-3 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Cultural & Architectural Significance (Hindi):' : 'सांस्कृतिक एवं वास्तुशिल्प महत्व (हिंदी):'}
                      </label>
                      <textarea
                        rows={4}
                        value={editingSite.hindiCulturalSignificance}
                        onChange={(e) => handleFieldChange('hindiCulturalSignificance', e.target.value)}
                        className="w-full p-3 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A] font-devanagari focus:outline-none focus:border-[#C05E42]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: FACTS & FOLKLORE */}
              {activeTab === 'facts' && (
                <div className="flex flex-col gap-6">
                  {/* Facts List */}
                  <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E2D9] flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold tracking-wider uppercase text-[#1A1A1A]">
                        {currentLang === 'en' ? 'Interesting Facts (English & Hindi Pairs)' : 'रोचक तथ्य (अंग्रेज़ी एवं हिंदी)'}
                      </h4>
                      <button
                        type="button"
                        onClick={() => {
                          const facts = editingSite.interestingFacts || [];
                          const hiFacts = editingSite.hindiInterestingFacts || [];
                          handleFieldChange('interestingFacts', [...facts, 'New interesting architectural or historical fact']);
                          handleFieldChange('hindiInterestingFacts', [...hiFacts, 'नया रोचक ऐतिहासिक तथ्य']);
                        }}
                        className="px-3 py-1 rounded-lg bg-[#C05E42] text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>{currentLang === 'en' ? '+ Add Fact' : '+ तथ्य जोड़ें'}</span>
                      </button>
                    </div>

                    <div className="flex flex-col gap-3">
                      {(editingSite.interestingFacts || []).map((fact, fIdx) => (
                        <div key={fIdx} className="p-3 rounded-xl bg-white border border-[#E8E2D9] flex flex-col gap-2 relative">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-[#8C827A]">
                              #{fIdx + 1}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                const facts = [...(editingSite.interestingFacts || [])];
                                const hiFacts = [...(editingSite.hindiInterestingFacts || [])];
                                facts.splice(fIdx, 1);
                                hiFacts.splice(fIdx, 1);
                                handleFieldChange('interestingFacts', facts);
                                handleFieldChange('hindiInterestingFacts', hiFacts);
                              }}
                              className="text-rose-600 hover:text-rose-800 text-[11px] font-bold cursor-pointer"
                            >
                              {currentLang === 'en' ? 'Remove' : 'हटाएं'}
                            </button>
                          </div>
                          <input
                            type="text"
                            value={fact}
                            onChange={(e) => {
                              const facts = [...(editingSite.interestingFacts || [])];
                              facts[fIdx] = e.target.value;
                              handleFieldChange('interestingFacts', facts);
                            }}
                            placeholder="English Fact"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-[#FAF8F5] border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                          />
                          <input
                            type="text"
                            value={(editingSite.hindiInterestingFacts || [])[fIdx] || ''}
                            onChange={(e) => {
                              const hiFacts = [...(editingSite.hindiInterestingFacts || [])];
                              hiFacts[fIdx] = e.target.value;
                              handleFieldChange('hindiInterestingFacts', hiFacts);
                            }}
                            placeholder="हिंदी तथ्य"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-[#FAF8F5] border border-[#E8E2D9] text-xs text-[#1A1A1A] font-devanagari"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Folklore / Oral Legends */}
                  <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E2D9] flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold tracking-wider uppercase text-[#1A1A1A]">
                        {currentLang === 'en' ? 'Folklore & Oral Traditions' : 'लोककथाएं एवं जनश्रुतियां'}
                      </h4>
                      <button
                        type="button"
                        onClick={() => {
                          const folk = editingSite.folkloreOrLegends || [];
                          const hiFolk = editingSite.hindiFolkloreOrLegends || [];
                          handleFieldChange('folkloreOrLegends', [...folk, 'Folklore / Oral Tradition: ...']);
                          handleFieldChange('hindiFolkloreOrLegends', [...hiFolk, 'लोककथा / जनश्रुति: ...']);
                        }}
                        className="px-3 py-1 rounded-lg bg-[#2C4A3E] text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>{currentLang === 'en' ? '+ Add Legend' : '+ कथा जोड़ें'}</span>
                      </button>
                    </div>

                    <div className="flex flex-col gap-3">
                      {(editingSite.folkloreOrLegends || []).map((legend, lIdx) => (
                        <div key={lIdx} className="p-3 rounded-xl bg-white border border-[#E8E2D9] flex flex-col gap-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-[#8C827A]">Legend #{lIdx + 1}</span>
                            <button
                              type="button"
                              onClick={() => {
                                const folk = [...(editingSite.folkloreOrLegends || [])];
                                const hiFolk = [...(editingSite.hindiFolkloreOrLegends || [])];
                                folk.splice(lIdx, 1);
                                hiFolk.splice(lIdx, 1);
                                handleFieldChange('folkloreOrLegends', folk);
                                handleFieldChange('hindiFolkloreOrLegends', hiFolk);
                              }}
                              className="text-rose-600 hover:text-rose-800 text-[11px] font-bold cursor-pointer"
                            >
                              {currentLang === 'en' ? 'Remove' : 'हटाएं'}
                            </button>
                          </div>
                          <textarea
                            rows={2}
                            value={legend}
                            onChange={(e) => {
                              const folk = [...(editingSite.folkloreOrLegends || [])];
                              folk[lIdx] = e.target.value;
                              handleFieldChange('folkloreOrLegends', folk);
                            }}
                            className="w-full p-2.5 rounded-lg bg-[#FAF8F5] border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                          />
                          <textarea
                            rows={2}
                            value={(editingSite.hindiFolkloreOrLegends || [])[lIdx] || ''}
                            onChange={(e) => {
                              const hiFolk = [...(editingSite.hindiFolkloreOrLegends || [])];
                              hiFolk[lIdx] = e.target.value;
                              handleFieldChange('hindiFolkloreOrLegends', hiFolk);
                            }}
                            className="w-full p-2.5 rounded-lg bg-[#FAF8F5] border border-[#E8E2D9] text-xs text-[#1A1A1A] font-devanagari"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: TRAVEL & LOGISTICS */}
              {activeTab === 'travel' && (
                <div className="flex flex-col gap-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Visiting Timings:' : 'खुलने का समय:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.travelTips?.timings || ''}
                        onChange={(e) => handleFieldChange('travelTips.timings', e.target.value)}
                        placeholder="e.g. 9:00 AM – 5:30 PM (Closed Mondays)"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Entry Fee Details:' : 'प्रवेश शुल्क विवरण:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.travelTips?.entryFee || ''}
                        onChange={(e) => handleFieldChange('travelTips.entryFee', e.target.value)}
                        placeholder="e.g. ₹35 for Indians, ₹500 for Foreigners"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Nearest Metro Station:' : 'निकटतम मेट्रो स्टेशन:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.travelTips?.nearestMetro || ''}
                        onChange={(e) => handleFieldChange('travelTips.nearestMetro', e.target.value)}
                        placeholder="e.g. Lal Qila (Violet Line)"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                        {currentLang === 'en' ? 'Best Time to Visit:' : 'भ्रमण का सर्वोत्तम समय:'}
                      </label>
                      <input
                        type="text"
                        value={editingSite.travelTips?.bestTimeToVisit || ''}
                        onChange={(e) => handleFieldChange('travelTips.bestTimeToVisit', e.target.value)}
                        placeholder="e.g. October to March"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1A1A1A] mb-1">
                      {currentLang === 'en' ? 'Visitor Rules & Guidelines (comma separated):' : 'आगंतुक नियम एवं दिशा-निर्देश:'}
                    </label>
                    <input
                      type="text"
                      value={editingSite.travelTips?.rules ? editingSite.travelTips.rules.join(', ') : ''}
                      onChange={(e) => handleFieldChange('travelTips.rules', e.target.value.split(',').map(r => r.trim()).filter(Boolean))}
                      placeholder="Photography allowed, Security check at gate"
                      className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                    />
                  </div>
                </div>
              )}

              {/* TAB 5: NEARBY ATTRACTIONS */}
              {activeTab === 'nearby' && (
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold tracking-wider uppercase text-[#1A1A1A]">
                      {currentLang === 'en' ? 'Nearby Attractions' : 'निकटवर्ती दर्शनीय स्थल'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => {
                        const current = editingSite.nearbyAttractions || [];
                        handleFieldChange('nearbyAttractions', [
                          ...current,
                          { name: 'New Attraction', distance: '500 m', description: 'Nearby heritage or culinary spot' }
                        ]);
                      }}
                      className="px-3 py-1 rounded-lg bg-[#C05E42] text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>{currentLang === 'en' ? '+ Add Attraction' : '+ आकर्षण जोड़ें'}</span>
                    </button>
                  </div>

                  <div className="flex flex-col gap-3">
                    {(editingSite.nearbyAttractions || []).map((attr, aIdx) => (
                      <div key={aIdx} className="p-3.5 rounded-xl bg-[#FDFBF7] border border-[#E8E2D9] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                        <div className="sm:col-span-4">
                          <label className="block text-[10px] font-bold text-[#8C827A] mb-0.5">Name</label>
                          <input
                            type="text"
                            value={attr.name}
                            onChange={(e) => {
                              const list = [...(editingSite.nearbyAttractions || [])];
                              list[aIdx] = { ...list[aIdx], name: e.target.value };
                              handleFieldChange('nearbyAttractions', list);
                            }}
                            className="w-full px-2 py-1 rounded-md bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-[#8C827A] mb-0.5">Distance</label>
                          <input
                            type="text"
                            value={attr.distance}
                            onChange={(e) => {
                              const list = [...(editingSite.nearbyAttractions || [])];
                              list[aIdx] = { ...list[aIdx], distance: e.target.value };
                              handleFieldChange('nearbyAttractions', list);
                            }}
                            placeholder="e.g. 400 m"
                            className="w-full px-2 py-1 rounded-md bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                          />
                        </div>
                        <div className="sm:col-span-4">
                          <label className="block text-[10px] font-bold text-[#8C827A] mb-0.5">Description</label>
                          <input
                            type="text"
                            value={attr.description}
                            onChange={(e) => {
                              const list = [...(editingSite.nearbyAttractions || [])];
                              list[aIdx] = { ...list[aIdx], description: e.target.value };
                              handleFieldChange('nearbyAttractions', list);
                            }}
                            className="w-full px-2 py-1 rounded-md bg-white border border-[#E8E2D9] text-xs text-[#1A1A1A]"
                          />
                        </div>
                        <div className="sm:col-span-1 flex justify-end">
                          <button
                            type="button"
                            onClick={() => {
                              const list = [...(editingSite.nearbyAttractions || [])];
                              list.splice(aIdx, 1);
                              handleFieldChange('nearbyAttractions', list);
                            }}
                            className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-100 transition-colors"
                            title="Remove"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 6: RAW JSON EDITOR */}
              {activeTab === 'json' && (
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-[#5C544E]">
                      {currentLang === 'en'
                        ? 'Directly view or modify the complete structured JSON payload for this monument.'
                        : 'इस स्मारक के संपूर्ण JSON डेटा को सीधे देखें अथवा संपादित करें।'}
                    </p>
                    <button
                      type="button"
                      onClick={handleApplyRawJson}
                      className="px-3.5 py-1.5 rounded-xl bg-[#2C4A3E] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{currentLang === 'en' ? 'Apply JSON Edits' : 'JSON लागू करें'}</span>
                    </button>
                  </div>

                  {rawJsonError && (
                    <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-bold">
                      {rawJsonError}
                    </div>
                  )}

                  <textarea
                    rows={16}
                    value={rawJsonEditText}
                    onChange={(e) => {
                      setRawJsonEditText(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full p-4 rounded-2xl bg-neutral-900 text-emerald-400 font-mono text-xs leading-relaxed focus:outline-none border border-neutral-800"
                    spellCheck={false}
                  />
                </div>
              )}

              {/* Bottom Sticky Action Banner */}
              <div className="p-4 rounded-2xl bg-[#F8F5F0] border border-[#E8E2D9] flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-xs text-[#5C544E]">
                  <span>{currentLang === 'en' ? 'Current monument:' : 'वर्तमान स्मारक:'}</span>{' '}
                  <strong className="text-[#1A1A1A]">{editingSite.name}</strong> ({editingSite.id})
                </div>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      const fresh = sites.find(s => s.id === editingSite.id);
                      if (fresh) {
                        setEditingSite(JSON.parse(JSON.stringify(fresh)));
                        setRawJsonEditText(JSON.stringify(fresh, null, 2));
                        setIsDirty(false);
                        showToast(currentLang === 'en' ? 'Reverted unsaved edits.' : 'बदलाव पूर्ववत किए गए।', 'info');
                      }
                    }}
                    disabled={!isDirty}
                    className="px-3 py-1.5 rounded-xl bg-white border border-[#E8E2D9] text-[#1A1A1A] text-xs font-bold disabled:opacity-40 cursor-pointer"
                  >
                    {currentLang === 'en' ? 'Discard Changes' : 'बदलाव छोड़ें'}
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveCurrentSite}
                    className="px-4 py-2 rounded-xl bg-[#C05E42] hover:bg-[#a84d34] text-white text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4 text-[#D4AF37]" />
                    <span>{currentLang === 'en' ? 'Save All Changes' : 'सभी बदलाव सहेजें'}</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-3xl border border-[#E8E2D9] text-xs text-[#8C827A]">
              {currentLang === 'en' ? 'Select a monument from the list on the left to view and edit its details.' : 'विवरण देखने और संपादित करने के लिए बाईं ओर से स्मारक चुनें।'}
            </div>
          )}
        </div>
      </div>

      {/* Modal: Add New Monument */}
      <AnimatePresence>
        {isNewSiteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg rounded-3xl bg-white p-6 border border-[#E8E2D9] shadow-2xl flex flex-col gap-5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-[#C05E42]" />
                  <h3 className="text-lg font-bold text-[#1A1A1A]">
                    {currentLang === 'en' ? 'Add New Heritage Monument' : 'नया धरोहर स्मारक जोड़ें'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsNewSiteModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-neutral-700"
                >
                  ✕
                </button>
              </div>

              <p className="text-xs text-[#5C544E] leading-relaxed">
                {currentLang === 'en'
                  ? 'Choose whether to create a fresh monument entry or base it on an existing temple/fort/minaret template.'
                  : 'नया खाली स्मारक प्रविष्टि बनाएं अथवा किसी मौजूदा स्मारक के टेम्पलेट पर आधारित करें।'}
              </p>

              <div className="flex flex-col gap-2.5">
                <button
                  type="button"
                  onClick={() => handleCreateNewSite()}
                  className="p-3.5 rounded-2xl bg-[#FAF8F5] hover:bg-[#F3EEE7] border border-[#E8E2D9] text-left text-xs font-bold text-[#1A1A1A] flex items-center justify-between group cursor-pointer"
                >
                  <div>
                    <div className="font-bold text-[#C05E42]">
                      {currentLang === 'en' ? '✨ Blank Heritage Template' : '✨ नया रिक्त टेम्पलेट'}
                    </div>
                    <div className="text-[11px] text-[#8C827A] font-normal mt-0.5">
                      {currentLang === 'en' ? 'Pre-filled with all ASI fields, facts structure, and coordinates' : 'सभी आवश्यक क्षेत्रों के साथ खाली ढांचा'}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#8C827A] group-hover:text-[#C05E42]" />
                </button>

                <div className="text-[11px] font-bold text-[#8C827A] uppercase tracking-wider mt-2">
                  {currentLang === 'en' ? 'Or Clone from Existing Monument:' : 'या मौजूदा स्मारक से क्लोन करें:'}
                </div>

                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {sites.slice(0, 6).map((site) => (
                    <button
                      key={site.id}
                      type="button"
                      onClick={() => handleCreateNewSite(site.id)}
                      className="p-2.5 rounded-xl bg-white hover:bg-[#FAF8F5] border border-[#E8E2D9] text-left text-xs text-[#1A1A1A] flex items-center gap-2 truncate cursor-pointer"
                    >
                      <Building2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                      <span className="truncate">{site.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E8E2D9]">
                <button
                  type="button"
                  onClick={() => setIsNewSiteModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#5C544E] hover:bg-neutral-100"
                >
                  {currentLang === 'en' ? 'Cancel' : 'रद्द करें'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Import JSON */}
      <AnimatePresence>
        {isImportModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-xl rounded-3xl bg-white p-6 border border-[#E8E2D9] shadow-2xl flex flex-col gap-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Upload className="w-5 h-5 text-[#C05E42]" />
                  <h3 className="text-lg font-bold text-[#1A1A1A]">
                    {currentLang === 'en' ? 'Import Heritage Sites JSON' : 'हेरिटेज साइट्स JSON आयात करें'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-neutral-700"
                >
                  ✕
                </button>
              </div>

              <p className="text-xs text-[#5C544E]">
                {currentLang === 'en'
                  ? 'Paste an array of HeritageSite JSON objects to update or replace the current catalog.'
                  : 'मौजूदा सूची को अद्यतन करने के लिए हेरिटेज साइट्स JSON ऐरे पेस्ट करें।'}
              </p>

              <textarea
                rows={10}
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                placeholder="[ { &quot;id&quot;: &quot;red-fort&quot;, &quot;name&quot;: &quot;Red Fort&quot;, ... } ]"
                className="w-full p-3 rounded-xl bg-neutral-900 text-emerald-400 font-mono text-xs leading-relaxed focus:outline-none"
              />

              <div className="flex justify-end gap-2.5 pt-2 border-t border-[#E8E2D9]">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#5C544E] hover:bg-neutral-100"
                >
                  {currentLang === 'en' ? 'Cancel' : 'रद्द करें'}
                </button>
                <button
                  type="button"
                  onClick={handleImportJson}
                  className="px-4 py-2 rounded-xl bg-[#2C4A3E] text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  {currentLang === 'en' ? 'Import Sites' : 'आयात करें'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

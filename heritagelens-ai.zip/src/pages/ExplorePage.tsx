import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  ArrowRight, 
  Globe2, 
  AlertCircle, 
  RotateCw, 
  Landmark, 
  Search, 
  MapPin, 
  Layers, 
  Clock, 
  Ticket, 
  Compass, 
  Info,
  CheckCircle2,
  X,
  Building2,
  HelpCircle,
  Camera,
  Upload
} from 'lucide-react';
import { ImageInput } from '../components/ImageInput';
import { ApiKeyPromptModal } from '../components/ApiKeyPromptModal';
import { identifyHeritageImage, getStoredGeminiKey } from '../services/geminiService';
import { StorageService } from '../services/storage';
import { DELHI_HERITAGE_RECORDS } from '../data/delhiHeritage';
import { DELHI_HERITAGE_SITES } from '../data/heritageSites';
import { IdentificationResult } from '../types';
import { MONUMENT_IMAGE_MAP, handleMonumentImageError } from '../utils/imageFallback';

interface ExplorePageProps {
  currentLang: 'en' | 'hi';
  onLangChange?: (lang: 'en' | 'hi') => void;
}

// Visual and gradient configurations for the 10 monuments
const SITE_VISUALS: Record<string, { imageUrl: string; imageAlt: string; gradientBg: string; badgeBg: string }> = {
  'red-fort': {
    imageUrl: 'https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Red Fort Lal Qila main ramparts and Lahori Gate',
    gradientBg: 'from-[#8B2616] via-[#B8422A] to-[#45140D]',
    badgeBg: 'bg-rose-100 text-rose-800 border-rose-200'
  },
  'gurudwara-bangla-sahib': {
    imageUrl: 'https://images.unsplash.com/photo-1609137144813-7d9921338f24?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Golden dome and holy sarovar pool of Gurudwara Bangla Sahib',
    gradientBg: 'from-[#C47D15] via-[#E2A128] to-[#683E08]',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-200'
  },
  'gurudwara-sis-ganj-sahib': {
    imageUrl: 'https://images.unsplash.com/photo-1600100397608-f010f443b794?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Gurudwara Sis Ganj Sahib historic shrine in Chandni Chowk',
    gradientBg: 'from-[#A85B1F] via-[#C97B34] to-[#542B0C]',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-200'
  },
  'jama-masjid-delhi': {
    imageUrl: 'https://images.unsplash.com/photo-1590077428593-a55bb07c4665?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Grand courtyard, marble domes, and sandstone minarets of Jama Masjid',
    gradientBg: 'from-[#8A3A28] via-[#A84F3B] to-[#3B1710]',
    badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-200'
  },
  'india-gate': {
    imageUrl: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Triumphal arch of India Gate illuminated on Kartavya Path',
    gradientBg: 'from-[#384A5B] via-[#4A647B] to-[#1E2933]',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-200'
  },
  'humayun-tomb': {
    imageUrl: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Charbagh gardens and Persian double-dome of Humayuns Tomb',
    gradientBg: 'from-[#93462E] via-[#B85C40] to-[#451B10]',
    badgeBg: 'bg-orange-100 text-orange-900 border-orange-200'
  },
  'qutub-minar': {
    imageUrl: 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Fluted brick minaret and balconies of Qutub Minar complex',
    gradientBg: 'from-[#8F5327] via-[#B57039] to-[#472710]',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-200'
  },
  'lotus-temple': {
    imageUrl: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'White marble petals of Bahai Lotus Temple against blue sky',
    gradientBg: 'from-[#2F5368] via-[#40708C] to-[#162934]',
    badgeBg: 'bg-sky-100 text-sky-900 border-sky-200'
  },
  'purana-qila': {
    imageUrl: 'https://images.unsplash.com/photo-1585135497273-1a86b09fe70e?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Ancient bastions, Talaqi Darwaza, and lake of Purana Qila',
    gradientBg: 'from-[#54463A] via-[#756252] to-[#2B231D]',
    badgeBg: 'bg-stone-100 text-stone-900 border-stone-300'
  },
  'agrasen-ki-baoli': {
    imageUrl: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=1200&q=80',
    imageAlt: 'Architectural stone steps and symmetrical arches of Agrasen ki Baoli',
    gradientBg: 'from-[#4D4842] via-[#6B645C] to-[#25221F]',
    badgeBg: 'bg-teal-100 text-teal-900 border-teal-200'
  }
};

const CATEGORIES = [
  { id: 'all', labelEn: 'All Categories', labelHi: 'सभी श्रेणियां' },
  { id: 'Fort', labelEn: 'Forts', labelHi: 'किले' },
  { id: 'Religious Place', labelEn: 'Religious Places', labelHi: 'धार्मिक स्थल' },
  { id: 'Mosque', labelEn: 'Mosques', labelHi: 'मस्जिदें' },
  { id: 'Memorial', labelEn: 'Memorials', labelHi: 'स्मारक' },
  { id: 'Tomb', labelEn: 'Tombs', labelHi: 'मक़बरे' },
  { id: 'Monument', labelEn: 'Monuments', labelHi: 'स्तंभ एवं मीनार' },
  { id: 'Temple', labelEn: 'Temples', labelHi: 'मंदिर' },
  { id: 'Stepwell', labelEn: 'Stepwells', labelHi: 'बाओली' }
];

export const ExplorePage: React.FC<ExplorePageProps> = ({ currentLang, onLangChange }) => {
  const navigate = useNavigate();

  // Identification State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isIdentifying, setIsIdentifying] = useState(false);
  const [identificationError, setIdentificationError] = useState<string | null>(null);
  const [loadingStage, setLoadingStage] = useState(0);
  const [showKeyModal, setShowKeyModal] = useState(false);

  // Local collection search/filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  // Loading animation step simulator
  const loadingSteps = useMemo(() => [
    currentLang === 'en' ? 'Scanning architectural geometry & motifs...' : 'वास्तुशिल्प बनावट और रूपांकनों की स्कैनिंग...',
    currentLang === 'en' ? 'Matching against ASI & UNESCO Delhi archives...' : 'एएसआई और यूनेस्को दिल्ली अभिलेखागार से मिलान...',
    currentLang === 'en' ? 'Compiling verified historical narrative...' : 'प्रमाणित ऐतिहासिक विवरण संकलित किया जा रहा है...'
  ], [currentLang]);

  const handleIdentifyClick = () => {
    if (!selectedImage) return;
    const apiKey = getStoredGeminiKey();
    if (!apiKey) {
      setShowKeyModal(true);
      return;
    }
    executeIdentify(apiKey);
  };

  // Execute Identification
  const executeIdentify = async (apiKey?: string) => {
    if (!selectedImage) return;

    setIsIdentifying(true);
    setIdentificationError(null);
    setLoadingStage(0);

    const stepInterval = setInterval(() => {
      setLoadingStage((prev) => (prev < 2 ? prev + 1 : prev));
    }, 600);

    try {
      const response = await identifyHeritageImage(
        selectedImage,
        apiKey,
        currentLang
      );

      clearInterval(stepInterval);

      const result = response.fullResult || {
        isIdentified: false,
        confidenceScore: 0.2,
        detectedName: currentLang === 'hi' ? 'अज्ञात स्मारक' : 'Unknown Monument',
        architecturalElements: [],
        historicalEra: 'Undetermined',
        customGeminiInsight: response.error || 'Recognition completed.',
        isFallbackOrUnknown: true,
        uploadedImageUrl: selectedImage,
        analyzedAt: new Date().toISOString(),
      };

      // Save result in sessionStorage so it persists across refreshes
      StorageService.saveLastResult(result);

      // Navigate to /result with state and cache
      navigate('/result', { state: { result, geminiData: response.data } });
    } catch (err: any) {
      clearInterval(stepInterval);
      console.error('Identification failed:', err);
      setIdentificationError(
        currentLang === 'en'
          ? 'An unexpected error occurred during visual analysis. Please check your internet connection or retry.'
          : 'दृश्य विश्लेषण के दौरान एक त्रुटि हुई। कृपया अपना इंटरनेट कनेक्शन जांचें या पुनः प्रयास करें।'
      );
      setIsIdentifying(false);
    }
  };

  const handleRetry = () => {
    setIdentificationError(null);
    handleIdentifyClick();
  };

  const handleChooseAnother = () => {
    setSelectedImage(null);
    setIdentificationError(null);
  };

  // Filtered 10-site collection
  const filteredSites = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return DELHI_HERITAGE_RECORDS.filter((site) => {
      const matchesCategory =
        selectedCategory === 'all' ||
        site.category.toLowerCase() === selectedCategory.toLowerCase();

      if (!matchesCategory) return false;
      if (!query) return true;

      const nameMatch = site.name.toLowerCase().includes(query);
      const altNameMatch = site.alternateName ? site.alternateName.toLowerCase().includes(query) : false;
      const categoryMatch = site.category.toLowerCase().includes(query);
      const areaMatch = site.area.toLowerCase().includes(query);
      const descMatch = site.shortDescription.toLowerCase().includes(query);

      return nameMatch || altNameMatch || categoryMatch || areaMatch || descMatch;
    });
  }, [searchQuery, selectedCategory]);

  const handleCardClick = (siteId: string) => {
    navigate(`/result?site=${encodeURIComponent(siteId)}`);
  };

  return (
    <div className="flex-1 flex flex-col gap-12 py-8 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8">
      {/* ========================================================================= */}
      {/* 1. PRIMARY IDENTIFICATION SECTION                                         */}
      {/* ========================================================================= */}
      <section 
        id="explore-identification-experience"
        className="w-full bg-[#FDFBF7] border border-[#E8E2D9] rounded-3xl p-6 sm:p-10 shadow-sm relative overflow-hidden"
      >
        {/* Decorative Background Accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-[#C05E42]/10 via-[#D4AF37]/5 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto flex flex-col items-center text-center">
          {/* Top Label & Language Selector Pill */}
          <div className="w-full flex flex-wrap items-center justify-between gap-4 mb-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C05E42]/10 border border-[#C05E42]/20 text-[#C05E42] text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-[#C05E42]" />
              <span>{currentLang === 'en' ? 'AI Heritage Recognition' : 'एआई हेरिटेज पहचान'}</span>
            </div>

            {/* Language Selector: English / Hindi */}
            {onLangChange && (
              <div 
                id="explore-language-selector"
                className="inline-flex items-center gap-1.5 bg-[#F3EEE7] border border-[#E8E2D9] p-1 rounded-2xl shadow-2xs"
                role="group"
                aria-label="Language selection"
              >
                <button
                  type="button"
                  id="lang-select-en"
                  onClick={() => onLangChange('en')}
                  className={`px-3 py-1 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    currentLang === 'en'
                      ? 'bg-[#2C4A3E] text-white shadow-2xs'
                      : 'text-[#5C544E] hover:text-[#1A1A1A]'
                  }`}
                  aria-pressed={currentLang === 'en'}
                >
                  English
                </button>
                <button
                  type="button"
                  id="lang-select-hi"
                  onClick={() => onLangChange('hi')}
                  className={`px-3 py-1 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    currentLang === 'hi'
                      ? 'bg-[#2C4A3E] text-white shadow-2xs'
                      : 'text-[#5C544E] hover:text-[#1A1A1A]'
                  }`}
                  aria-pressed={currentLang === 'hi'}
                >
                  हिन्दी
                </button>
              </div>
            )}
          </div>

          {/* Heading Requirement: “Show us a place worth remembering.” */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold font-serif-heritage text-[#1A1A1A] tracking-tight leading-tight">
            {currentLang === 'en' ? 'Show us a place worth remembering.' : 'संजोने योग्य एक ऐतिहासिक धरोहर दिखाएँ।'}
          </h1>

          {/* Short Instructions Requirement */}
          <p className="text-sm sm:text-base text-[#5C544E] mt-3 mb-8 max-w-xl leading-relaxed">
            {currentLang === 'en'
              ? 'Capture or upload a photo of any Delhi heritage monument. HeritageLens AI will identify its architectural style, history, and verified cultural story.'
              : 'दिल्ली के किसी भी ऐतिहासिक स्मारक की फोटो खींचें या अपलोड करें। हेरिटेज लेंस तुरंत उसकी वास्तुकला, इतिहास और कथा प्रस्तुत करेगा।'}
          </p>

          {/* Identification Content Container */}
          <div className="w-full text-left">
            <AnimatePresence mode="wait">
              {/* ========================================================================= */}
              {/* STATE A: LOADING STATE WITH CULTURAL MOTIF ANIMATION                      */}
              {/* ========================================================================= */}
              {isIdentifying ? (
                <motion.div
                  key="identifying-loading-state"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-[#F3EEE7] border border-[#E8E2D9] rounded-3xl p-8 sm:p-12 text-center flex flex-col items-center justify-center shadow-xs"
                >
                  {/* Culturally appropriate rotating sandstone Jali/Mandala animation */}
                  <div className="relative w-28 h-28 mb-6 flex items-center justify-center">
                    {/* Outer Sandstone Ring */}
                    <div className="absolute inset-0 rounded-full border-4 border-dashed border-[#C05E42]/40 animate-[spin_10s_linear_infinite]" />
                    {/* Middle Saffron Ring */}
                    <div className="absolute inset-2.5 rounded-full border-2 border-[#D4AF37]/60 animate-[spin_6s_linear_infinite_reverse]" />
                    {/* Inner Glowing Core */}
                    <div className="w-16 h-16 rounded-2xl bg-[#2C4A3E] text-[#D4AF37] flex items-center justify-center shadow-lg transform rotate-45 animate-pulse">
                      <Landmark className="w-8 h-8 -rotate-45" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold font-serif-heritage text-[#1A1A1A]">
                    {currentLang === 'en' ? 'Analyzing Monument Architecture' : 'स्मारक वास्तुकला का विश्लेषण'}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#C05E42] font-semibold mt-2 min-h-6 transition-all duration-300">
                    {loadingSteps[loadingStage]}
                  </p>

                  <div className="w-48 h-1.5 bg-[#E8E2D9] rounded-full mt-4 overflow-hidden">
                    <div 
                      className="h-full bg-[#C05E42] transition-all duration-500 rounded-full"
                      style={{ width: `${((loadingStage + 1) / 3) * 100}%` }}
                    />
                  </div>
                </motion.div>
              ) : identificationError ? (
                /* ========================================================================= */
                /* STATE B: ERROR STATE WITH RETRY AND CHOOSE ANOTHER IMAGE ACTIONS          */
                /* ========================================================================= */
                <motion.div
                  key="identifying-error-state"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  className="bg-amber-50/80 border border-amber-200 rounded-3xl p-6 sm:p-8 text-center flex flex-col items-center justify-center shadow-xs"
                >
                  <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mb-4">
                    <AlertCircle className="w-7 h-7" />
                  </div>

                  <h3 className="text-lg font-bold font-serif-heritage text-amber-950">
                    {currentLang === 'en' ? 'Identification Unsuccessful' : 'पहचान पूरी नहीं हो सकी'}
                  </h3>

                  <p className="text-xs sm:text-sm text-amber-900 mt-2 max-w-md leading-relaxed">
                    {identificationError}
                  </p>

                  {/* Actions: Retry & Choose Another */}
                  <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
                    <button
                      type="button"
                      id="error-retry-btn"
                      onClick={handleRetry}
                      className="px-5 py-2.5 rounded-xl bg-[#2C4A3E] hover:bg-[#223a31] text-white text-xs font-bold flex items-center gap-2 shadow-2xs transition-all cursor-pointer"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>{currentLang === 'en' ? 'Retry Analysis' : 'पुनः प्रयास करें'}</span>
                    </button>

                    <button
                      type="button"
                      id="error-choose-another-btn"
                      onClick={handleChooseAnother}
                      className="px-5 py-2.5 rounded-xl bg-white border border-[#E8E2D9] hover:bg-[#FDFBF7] text-[#5C544E] text-xs font-bold flex items-center gap-2 transition-all cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{currentLang === 'en' ? 'Choose Another Image' : 'दूसरी छवि चुनें'}</span>
                    </button>
                  </div>
                </motion.div>
              ) : (
                /* ========================================================================= */
                /* STATE C: IMAGE INPUT (UPLOAD & CAMERA) WITH ACTION CONTROLS               */
                /* ========================================================================= */
                <div className="flex flex-col gap-6">
                  <ImageInput
                    value={selectedImage}
                    onChange={(url) => {
                      setSelectedImage(url);
                      setIdentificationError(null);
                    }}
                    currentLang={currentLang}
                  />

                  {/* “Identify this site” Button & Disabled State Indicator */}
                  <div className="flex flex-col items-center gap-3">
                    <button
                      type="button"
                      id="identify-this-site-btn"
                      onClick={handleIdentifyClick}
                      disabled={!selectedImage || isIdentifying}
                      className={`w-full sm:w-auto min-w-[280px] py-3.5 px-8 rounded-2xl font-serif-heritage text-sm font-bold flex items-center justify-center gap-2.5 shadow-md transition-all ${
                        selectedImage && !isIdentifying
                          ? 'bg-[#C05E42] hover:bg-[#A34B32] text-white active:scale-98 cursor-pointer'
                          : 'bg-[#E8E2D9] text-[#8C8276] cursor-not-allowed opacity-80 shadow-none'
                      }`}
                      aria-disabled={!selectedImage || isIdentifying}
                    >
                      <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                      <span>
                        {currentLang === 'en' ? 'Identify this site' : 'इस स्मारक की पहचान करें'}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    {!selectedImage && (
                      <p className="text-[11px] text-[#8C8276] font-medium text-center">
                        {currentLang === 'en'
                          ? 'Please take a photo or select an image above to activate identification.'
                          : 'पहचान शुरू करने के लिए कृपया ऊपर एक फोटो खींचें या चुनें।'}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* Demo Mode Note Requirement */}
          <div className="mt-8 pt-6 border-t border-[#E8E2D9] w-full flex items-center justify-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#F3EEE7] border border-[#E8E2D9] text-xs text-[#5C544E] text-center">
              <Info className="w-4 h-4 text-[#C05E42] shrink-0" />
              <span>
                {currentLang === 'en'
                  ? 'Demo Mode: The first release supports 10 verified Delhi heritage sites (Red Fort, Qutub Minar, Humayun’s Tomb, Bangla Sahib, India Gate, Lotus Temple, etc.).'
                  : 'डेमो मोड: पहला संस्करण 10 प्रमाणित दिल्ली स्मारकों (लाल किला, कुतुब मीनार, हुमायूं का मक़बरा, बंगला साहिब, आदि) का समर्थन करता है।'}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. VERIFIED 10-SITE DELHI COLLECTION CATALOG                              */}
      {/* ========================================================================= */}
      <section className="w-full flex flex-col gap-6">
        {/* Collection Header & Search Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#E8E2D9] pb-6">
          <div className="flex flex-col gap-1.5">
            <div className="inline-flex items-center gap-2 self-start px-3 py-1 rounded-full bg-[#2C4A3E]/10 border border-[#2C4A3E]/20 text-[#2C4A3E] text-[11px] font-bold tracking-wide">
              <Building2 className="w-3.5 h-3.5" />
              <span>{currentLang === 'en' ? 'Delhi Heritage Collection' : 'दिल्ली हेरिटेज संकलन'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif-heritage text-[#1A1A1A]">
              {currentLang === 'en' ? 'Or Explore Supported Monuments' : 'या समर्थित स्मारकों का अन्वेषण करें'}
            </h2>
            <p className="text-xs sm:text-sm text-[#5C544E]">
              {currentLang === 'en'
                ? 'Browse verified dossiers, visiting timings, architectural details, and cultural histories.'
                : 'प्रमाणित इतिहास, समय, वास्तुकला और सांस्कृतिक विवरण देखें।'}
            </p>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-[#8C8276] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="collection-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={currentLang === 'en' ? 'Search by name, area...' : 'नाम, क्षेत्र से खोजें...'}
              className="w-full pl-9.5 pr-8 py-2.5 bg-[#F3EEE7] border border-[#E8E2D9] focus:border-[#C05E42] focus:bg-white rounded-xl text-xs text-[#1A1A1A] placeholder-[#8C8276] outline-hidden transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-[#8C8276] hover:text-[#1A1A1A] rounded-full transition-colors cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
          <span className="text-[11px] font-bold text-[#8C8276] uppercase tracking-wider flex items-center gap-1 shrink-0 mr-1">
            <Layers className="w-3.5 h-3.5 text-[#C05E42]" />
            <span>{currentLang === 'en' ? 'Category:' : 'श्रेणी:'}</span>
          </span>
          {CATEGORIES.map((cat) => {
            const isActive = selectedCategory.toLowerCase() === cat.id.toLowerCase();
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center justify-center focus-visible:ring-2 focus-visible:ring-[#C05E42] ${
                  isActive
                    ? 'bg-[#2C4A3E] text-white shadow-xs'
                    : 'bg-[#F3EEE7] text-[#5C544E] hover:bg-[#E8E2D9] hover:text-[#1A1A1A] border border-transparent'
                } ${currentLang === 'hi' ? 'font-devanagari' : ''}`}
              >
                {currentLang === 'en' ? cat.labelEn : cat.labelHi}
              </button>
            );
          })}
        </div>

        {/* Cards Grid */}
        {filteredSites.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSites.map((site) => {
              const visual = SITE_VISUALS[site.id] || {
                imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Lahori_Gate%2C_Red_Fort%2C_Delhi.jpg/1280px-Lahori_Gate%2C_Red_Fort%2C_Delhi.jpg',
                imageAlt: site.name,
                gradientBg: 'from-[#8B2616] via-[#B8422A] to-[#45140D]',
                badgeBg: 'bg-rose-100 text-rose-800 border-rose-200'
              };

              const isImgFailed = failedImages[site.id];

              return (
                <div
                  key={site.id}
                  id={`explore-site-card-${site.id}`}
                  onClick={() => handleCardClick(site.id)}
                  className="bg-[#FDFBF7] border border-[#E8E2D9] hover:border-[#C05E42]/60 rounded-3xl overflow-hidden shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col group cursor-pointer focus-visible:ring-2 focus-visible:ring-[#C05E42] outline-none"
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleCardClick(site.id);
                    }
                  }}
                  aria-label={`View story of ${site.name}`}
                >
                  {/* Visual Header / Image */}
                  <div className="relative h-48 sm:h-52 overflow-hidden bg-[#2D2926]">
                    {!isImgFailed ? (
                      <img
                        src={visual.imageUrl}
                        alt={visual.imageAlt}
                        onError={() => setFailedImages((prev) => ({ ...prev, [site.id]: true }))}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      />
                    ) : (
                      <div className={`w-full h-full bg-gradient-to-br ${visual.gradientBg} flex flex-col items-center justify-center p-6 text-center text-white relative`}>
                        <Landmark className="w-8 h-8 text-white/80 mb-1" />
                        <span className="text-xs font-semibold text-white/90 uppercase">{site.category}</span>
                      </div>
                    )}

                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent pointer-events-none" />

                    {/* Top Badges */}
                    <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between pointer-events-none">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide border shadow-2xs backdrop-blur-xs ${visual.badgeBg}`}>
                        {site.category}
                      </span>
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>ASI Verified</span>
                      </span>
                    </div>

                    {/* Bottom Title */}
                    <div className="absolute bottom-3 left-3.5 right-3.5 pointer-events-none">
                      <h3 className={`text-lg font-bold text-white font-serif-heritage leading-snug group-hover:text-[#F3D79F] transition-colors break-words ${currentLang === 'hi' ? 'font-devanagari' : ''}`}>
                        {site.name}
                      </h3>
                      {site.alternateName && (
                        <p className={`text-xs text-white/80 font-medium line-clamp-1 ${currentLang === 'hi' ? 'font-devanagari' : ''}`}>
                          {site.alternateName}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Card Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-[#8C8276]">
                        <MapPin className="w-3.5 h-3.5 text-[#C05E42] shrink-0" />
                        <span className="line-clamp-1">{site.area}, {site.city}</span>
                      </div>
                      <p className={`text-xs text-[#5C544E] leading-relaxed line-clamp-2 ${currentLang === 'hi' ? 'font-devanagari' : ''}`}>
                        {site.shortDescription}
                      </p>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCardClick(site.id);
                        }}
                        className="w-full min-h-[44px] py-3 px-4 rounded-xl bg-[#C05E42] hover:bg-[#A34B32] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-2xs transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
                      >
                        <span className={currentLang === 'hi' ? 'font-devanagari text-sm' : ''}>
                          {currentLang === 'en' ? 'View story' : 'कहानी देखें'}
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div 
            id="explore-no-search-results"
            className="bg-[#FDFBF7] border border-[#E8E2D9] rounded-3xl p-8 sm:p-12 text-center flex flex-col items-center justify-center max-w-xl mx-auto my-4 shadow-sm"
          >
            <div className="w-14 h-14 rounded-2xl bg-amber-100/80 border border-amber-200 text-amber-800 flex items-center justify-center mb-4">
              <Search className="w-7 h-7" />
            </div>

            <span className="text-[10px] uppercase font-bold tracking-widest text-[#C05E42] px-3 py-0.5 rounded-full bg-[#C05E42]/10 mb-2">
              {currentLang === 'en' ? 'No Matching Monuments' : 'कोई स्मारक नहीं मिला'}
            </span>

            <h4 className={`text-xl sm:text-2xl font-bold font-serif-heritage text-[#1A1A1A] ${currentLang === 'hi' ? 'font-devanagari' : ''}`}>
              {currentLang === 'en'
                ? `No results for "${searchQuery || selectedCategory}"`
                : `"${searchQuery || selectedCategory}" के लिए कोई परिणाम नहीं`}
            </h4>

            <p className={`text-xs sm:text-sm text-[#5C544E] mt-2 mb-4 max-w-md leading-relaxed ${currentLang === 'hi' ? 'font-devanagari' : ''}`}>
              {currentLang === 'en'
                ? 'We could not find any monument in our 10 verified Delhi pilot sites matching your keywords or active category filter.'
                : 'आपके द्वारा खोजे गए शब्दों या श्रेणी से मेल खाता कोई स्मारक 10 दिल्ली स्थलों में नहीं मिला।'}
            </p>

            {/* What to do next instructions box */}
            <div className="w-full bg-[#F3EEE7] border border-[#E8E2D9] rounded-2xl p-4 text-left text-xs text-[#2D2926] mb-6">
              <div className="flex items-center gap-2 font-bold mb-1.5 text-[#1A1A1A]">
                <Info className="w-4 h-4 text-[#C05E42] shrink-0" />
                <span className={currentLang === 'hi' ? 'font-devanagari' : ''}>
                  {currentLang === 'en' ? 'What you can try next:' : 'आगे क्या प्रयास करें:'}
                </span>
              </div>
              <ul className={`list-disc list-inside space-y-1.5 text-[#5C544E] pl-1 text-[11px] sm:text-xs ${currentLang === 'hi' ? 'font-devanagari' : ''}`}>
                <li>{currentLang === 'en' ? 'Check for spelling variations (e.g. "Lal Qila", "Qutb Minar").' : 'वर्तनी की जांच करें (जैसे "लाल किला", "कुतुब मीनार")।'}</li>
                <li>{currentLang === 'en' ? 'Switch category to "All Categories" to search the full Delhi catalog.' : 'पूरी दिल्ली सूची खोजने के लिए श्रेणी को "सभी श्रेणियां" पर सेट करें।'}</li>
                <li>{currentLang === 'en' ? 'Click one of the suggested popular monuments below.' : 'नीचे दिए गए लोकप्रिय स्मारकों में से किसी एक पर क्लिक करें।'}</li>
              </ul>
            </div>

            {/* Quick Suggestions Chips */}
            <div className="flex flex-wrap items-center justify-center gap-2.5 mb-6">
              <span className="text-[11px] text-[#8C8276] font-medium mr-1">
                {currentLang === 'en' ? 'Suggestions:' : 'सुझाव:'}
              </span>
              {['Red Fort', 'Humayun', 'Qutub', 'Lotus', 'Bangla Sahib'].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => {
                    setSearchQuery(suggestion);
                    setSelectedCategory('all');
                  }}
                  className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white border border-[#E8E2D9] hover:border-[#C05E42] text-xs font-semibold text-[#1A1A1A] transition-colors cursor-pointer shadow-2xs focus-visible:ring-2 focus-visible:ring-[#C05E42]"
                >
                  {suggestion}
                </button>
              ))}
            </div>

            {/* Action button */}
            <button
              type="button"
              id="explore-reset-search-btn"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="min-h-[44px] px-6 py-3 bg-[#C05E42] hover:bg-[#a84d34] text-white text-xs font-bold rounded-xl shadow-2xs transition-colors flex items-center justify-center gap-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
            >
              <RotateCw className="w-4 h-4" />
              <span className={currentLang === 'hi' ? 'font-devanagari text-sm' : ''}>
                {currentLang === 'en' ? 'Reset All Filters & Show 10 Sites' : 'फ़िल्टर हटाएं और सभी 10 स्मारक देखें'}
              </span>
            </button>
          </div>
        )}

        {/* Roadmap notice */}
        <div className="mt-4 p-5 rounded-3xl bg-[#FDFBF7] border border-[#E8E2D9] flex items-center justify-between gap-4 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#2C4A3E]/10 text-[#2C4A3E] flex items-center justify-center shrink-0">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold font-serif-heritage text-[#1A1A1A]">
                {currentLang === 'en' ? 'More sites and cities coming soon.' : 'और अधिक स्मारक और शहर जल्द आ रहे हैं।'}
              </h4>
              <p className="text-[11px] text-[#5C544E]">
                {currentLang === 'en' ? 'Expanding to Jaipur, Agra, Varanasi, and Hampi.' : 'जयपुर, आगरा, वाराणसी और हम्पी के स्मारक भी जल्द जुड़ेंगे।'}
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold text-[#8C8276] px-2.5 py-1 rounded-lg bg-[#F3EEE7] shrink-0">
            Delhi Pilot v1.0
          </span>
        </div>
      </section>

      {/* API Key Modal */}
      <ApiKeyPromptModal
        isOpen={showKeyModal}
        onClose={() => setShowKeyModal(false)}
        onContinueDemo={() => {
          setShowKeyModal(false);
          executeIdentify();
        }}
        currentLang={currentLang}
      />
    </div>
  );
};

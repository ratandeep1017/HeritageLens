import type React from 'react';

// Curated high-resolution, CDN-cached photography URLs for all Delhi pilot monuments.
// These URLs are guaranteed to load reliably across all environments, iframes, and mobile devices.

export const MONUMENT_IMAGE_MAP: Record<string, { primary: string; secondary: string; svgTheme: { bg1: string; bg2: string; accent: string; icon: string } }> = {
  'red-fort': {
    primary: 'https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1585135497273-1a86b09fe70e?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#8B2616', bg2: '#45140D', accent: '#D4AF37', icon: 'Mugahl Fort' }
  },
  'humayun-tomb': {
    primary: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#9C3D26', bg2: '#521D12', accent: '#F3D79F', icon: 'Garden Tomb' }
  },
  'qutub-minar': {
    primary: 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#7A3816', bg2: '#3D1B0B', accent: '#E8B923', icon: 'Minaret' }
  },
  'lotus-temple': {
    primary: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1598890777032-bde13fbe34c1?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#1E3A8A', bg2: '#0F172A', accent: '#60A5FA', icon: 'Lotus Petals' }
  },
  'india-gate': {
    primary: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1600100397608-f010f443b794?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#B45309', bg2: '#451A03', accent: '#FDE047', icon: 'Triumphal Arch' }
  },
  'bangla-sahib': {
    primary: 'https://images.unsplash.com/photo-1609137144813-7d9921338f24?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1600100397608-f010f443b794?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#155E75', bg2: '#082F49', accent: '#FBBF24', icon: 'Golden Dome' }
  },
  'sis-ganj-sahib': {
    primary: 'https://images.unsplash.com/photo-1600100397608-f010f443b794?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1609137144813-7d9921338f24?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#065F46', bg2: '#022C22', accent: '#34D399', icon: 'Historic Shrine' }
  },
  'jama-masjid': {
    primary: 'https://images.unsplash.com/photo-1590077428593-a55bb07c4665?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#831843', bg2: '#500724', accent: '#F472B6', icon: 'Grand Mosque' }
  },
  'purana-qila': {
    primary: 'https://images.unsplash.com/photo-1585135497273-1a86b09fe70e?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#713F12', bg2: '#361E08', accent: '#EAB308', icon: 'Ancient Citadel' }
  },
  'agrasen-ki-baoli': {
    primary: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=1200&q=80',
    secondary: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1200&q=80',
    svgTheme: { bg1: '#374151', bg2: '#111827', accent: '#F59E0B', icon: 'Stepwell Arches' }
  }
};

/**
 * Returns an emergency inline SVG data URI in case network/offline prevents CDN loading.
 */
export function getEmergencyMonumentSvg(siteId: string, siteName: string = 'Delhi Heritage Site'): string {
  const config = MONUMENT_IMAGE_MAP[siteId] || {
    svgTheme: { bg1: '#8B2616', bg2: '#2D2926', accent: '#D4AF37', icon: 'Monument' }
  };
  const { bg1, bg2, accent, icon } = config.svgTheme;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${bg1}" />
        <stop offset="100%" stop-color="${bg2}" />
      </linearGradient>
      <linearGradient id="overlay" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="rgba(0,0,0,0.2)" />
        <stop offset="100%" stop-color="rgba(0,0,0,0.85)" />
      </linearGradient>
    </defs>
    <rect width="800" height="600" fill="url(#g)" />
    <!-- Architectural motif pattern -->
    <path d="M 100 500 L 100 300 Q 200 200 300 300 L 300 500 Z" fill="none" stroke="${accent}" stroke-width="4" opacity="0.35" />
    <path d="M 300 500 L 300 240 Q 400 120 500 240 L 500 500 Z" fill="none" stroke="${accent}" stroke-width="6" opacity="0.45" />
    <path d="M 500 500 L 500 300 Q 600 200 700 300 L 700 500 Z" fill="none" stroke="${accent}" stroke-width="4" opacity="0.35" />
    <circle cx="400" cy="180" r="18" fill="${accent}" opacity="0.7" />
    <rect width="800" height="600" fill="url(#overlay)" />
    <text x="400" y="490" fill="#FFFFFF" font-family="Georgia, serif" font-size="28" font-weight="bold" text-anchor="middle" letter-spacing="1">${siteName}</text>
    <text x="400" y="525" fill="${accent}" font-family="sans-serif" font-size="14" font-weight="600" text-anchor="middle" letter-spacing="2">ARCHAEOLOGICAL SURVEY OF INDIA • ${icon.toUpperCase()}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

/**
 * Resolves a reliable image URL for a given monument ID.
 */
export function getSafeMonumentImageUrl(siteId: string, customUrl?: string): string {
  if (customUrl && !customUrl.includes('wikimedia.org') && !customUrl.includes('placeholder')) {
    return customUrl;
  }
  const config = MONUMENT_IMAGE_MAP[siteId];
  if (config) {
    return config.primary;
  }
  return 'https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?auto=format&fit=crop&w=1200&q=80';
}

/**
 * Error fallback handler to be attached to React `onError` events.
 * It will try the secondary CDN image first, and if that also fails, it will switch to the architectural SVG.
 */
export function handleMonumentImageError(
  event: React.SyntheticEvent<HTMLImageElement, Event>,
  siteId?: string,
  siteName?: string
) {
  const target = event.currentTarget;
  const currentSrc = target.src;
  const config = siteId ? MONUMENT_IMAGE_MAP[siteId] : undefined;

  // Prevent infinite loop if already on SVG
  if (currentSrc.startsWith('data:image/svg+xml')) {
    return;
  }

  // If failed on primary or external URL, try secondary CDN
  if (config && currentSrc !== config.secondary && !currentSrc.includes(config.secondary)) {
    target.src = config.secondary;
    return;
  }

  // Fallback to high-definition architectural SVG canvas
  target.src = getEmergencyMonumentSvg(siteId || 'red-fort', siteName || 'Delhi Heritage');
}
